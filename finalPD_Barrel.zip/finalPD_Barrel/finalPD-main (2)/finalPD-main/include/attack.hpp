#pragma once
#include "me.hpp"
#include <vector>
#include "object.hpp"
#include <raylib.h>

// Base class for all attack controllers, attack instances stored in attackManager
class AttackController
{
protected:
    // Pointer to the entity that spawned this attack
    AttackController(Entity *_spawnedBy) : spawnedBy(_spawnedBy) {}

public:
    Entity *const spawnedBy; // The entity (player or enemy) that spawned this attack
    virtual void update() = 0; // Pure virtual function to update the attack
    virtual void draw() {}     // Virtual function for custom rendering
};

// logic for the "Thousand Attack" ability
class ThousandAttack : public AttackController
{
private:
    static constexpr float finalVel = 30; // Final velocity of projectiles during the final phase
    static constexpr int activate = 3;    // Number of projectiles required to activate the final phase
    Vector3 dest;                         // Destination point for the projectiles in the final phase
    int count;                            // Number of projectiles currently active
    bool activated;                       // Whether the final phase has been activated
    std::vector<Projectile> projectiles;  // List of projectiles spawned by this attack

    // Activates the final phase of the attack, making all projectiles move toward a single point
    void activateFinal();

    // Checks if the final phase is complete (all projectiles have reached the destination)
    bool endFinal();

public:
    // Constructor initializes the attack with the spawning entity
    ThousandAttack(Entity *_spawnedBy) : AttackController(_spawnedBy)
    {
        this->count = 0;
        this->activated = false;
    }

    // Spawns a new projectile for this attack
    void spawnProjectile();

    // Updates the state of the attack (e.g., moves projectiles, checks for activation)
    void update() override;

    // Returns a list of objects representing the projectiles for rendering or collision detection
    std::vector<const Object *> obj()
    {
        std::vector<const Object *> ret;
        for (const auto &p : this->projectiles)
            ret.push_back(&p.obj());
        return ret;
    }
};

class TripletAttack : public AttackController
{
private:
    enum TripletState
    {
        READY,
        SHOOTING,
        CONNECTING,
        FINAL,
        DONE
    };
    TripletState state;
    Vector3 averageConnectorPos;
    bool isFalling;
    float fallingTimer;
    std::vector<Projectile> projectiles;
    std::vector<float> connectorForward;
    float connectingTimer;

    // Connector objects (long thin boxes) that visually connect projectiles.
    // These are created when transitioning to CONNECTING and exposed via obj().
    std::vector<Object> connectors;
    static constexpr float connectorThickness = 0.15f; // thickness of the connector boxes
    static constexpr float finalHeight = 6.0f;
    static constexpr float finalGrowthRate = 0.15f;
public:
    TripletAttack(Entity *_spawnedBy) : AttackController(_spawnedBy)
    {
        state = READY;
        connectingTimer = 0;
        isFalling = false;
        fallingTimer = 0.f;
    }

    void spawnProjectile();
    void update() override;

    // Return projectile objects and connector objects for rendering
    std::vector<const Object *> obj()
    {
        std::vector<const Object *> ret;
        for (const auto &p : this->projectiles)
            ret.push_back(&p.obj());
        for (const auto &c : this->connectors)
            ret.push_back(&c);
        return ret;
    }
};

class BarrelAttack : public AttackController
{
private:
    enum BarrelState
    {
        Ready,          
        FiringRows,    
        MatrixFormed,   
        Advancing,      
        Done            
    };
    //the BarrelAttack will shoot 9 bullets, and they will form like a 3*3 matrix (this could be change later, while we may have 5 barrels or others)

    BarrelState state;
    std::vector<Projectile> projectiles;

    int rows_fired;
    float row_fire_timer;
    static constexpr float row_interval = 0.5f; 

    bool matrix_formed;
    Vector3 matrix_center;
    static constexpr float matrix_height = 2.0f;
    static constexpr float matrix_width = 2.0f;

    Vector3 dimension_forward;
    static constexpr float forward_speed = 18.0f;
    float shooting_timer;
    static constexpr float max_shooting_time = 3.0f;

    void fireCurrentRow();
    Vector3 calculateRowPosition(int row, int col);

public:
    BarrelAttack(Entity *_spawnedBy) : AttackController(_spawnedBy)
    {
        state = Ready;
        rows_fired = 0;
        row_fire_timer = 0.0f;
        matrix_formed = false;
        matrix_center = {0, 0, 0};
        dimension_forward = {0, 0, 0};
        shooting_timer = 0.0f;
    }

    void spawnProjectile();
    void update() override;

    std::vector<const Object *> obj()
    {
        std::vector<const Object *> ret;
        for (const auto &p : this->projectiles)
            ret.push_back(&p.obj());
        return ret;
    }
};
